from pyuvm import *
from cocotb.triggers import RisingEdge

class AHBMonitor(uvm_component):
    def build_phase(self):
        self.ap = uvm_analysis_port("ap", self)

    async def run_phase(self):
        while True:
            await RisingEdge(self.dut.HCLK)
            if int(self.dut.HTRANS.value) in [2, 3]:
                txn = {
                    "addr": int(self.dut.HADDR.value),
                    "write": int(self.dut.HWRITE.value),
                    "data": int(self.dut.HWDATA.value),
                    "rdata": int(self.dut.HRDATA.value)
                }
                self.ap.write(txn)
