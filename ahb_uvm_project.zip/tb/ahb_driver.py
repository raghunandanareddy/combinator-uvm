from pyuvm import *
from cocotb.triggers import RisingEdge

class AHBDriver(uvm_driver):
    async def run_phase(self):
        while True:
            txn = await self.seq_item_port.get_next_item()
            for i in range(txn.length):
                self.dut.HADDR.value = txn.addr + (i * 4)
                self.dut.HWRITE.value = txn.write
                self.dut.HTRANS.value = 2 if i == 0 else 3
                await RisingEdge(self.dut.HCLK)
                while not int(self.dut.HREADY.value):
                    await RisingEdge(self.dut.HCLK)
                if txn.write:
                    self.dut.HWDATA.value = txn.data + i
            self.dut.HTRANS.value = 0
            self.seq_item_port.item_done()
