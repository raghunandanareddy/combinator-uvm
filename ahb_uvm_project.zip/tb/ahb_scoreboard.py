from pyuvm import *

class AHBScoreboard(uvm_component):
    def build_phase(self):
        self.analysis_export = uvm_analysis_export("analysis_export", self)
        self.fifo = uvm_tlm_analysis_fifo("fifo", self)
        self.mem = {}

    def connect_phase(self):
        self.analysis_export.connect(self.fifo.analysis_export)

    async def run_phase(self):
        while True:
            txn = await self.fifo.get()
            addr = txn["addr"]
            if txn["write"]:
                self.mem[addr] = txn["data"]
            else:
                expected = self.mem.get(addr, 0)
                assert expected == txn["rdata"], f"Mismatch @ {addr}"
