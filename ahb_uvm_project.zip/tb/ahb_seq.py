from pyuvm import *
import random
from ahb_transaction import AHBTransaction

class AHBBurstSeq(uvm_sequence):
    async def body(self):
        for _ in range(5):
            txn = AHBTransaction()
            txn.addr = random.randint(0, 64) * 4
            txn.write = random.choice([0, 1])
            txn.data = random.randint(0, 255)
            txn.burst = random.choice(["SINGLE", "INCR"])
            txn.length = 1 if txn.burst == "SINGLE" else 4
            await self.start_item(txn)
            await self.finish_item(txn)
