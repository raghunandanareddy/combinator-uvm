from pyuvm import *
from ahb_driver import AHBDriver
from ahb_monitor import AHBMonitor
from ahb_scoreboard import AHBScoreboard

class AHBEnv(uvm_env):
    def build_phase(self):
        self.driver = AHBDriver("driver", self)
        self.monitor = AHBMonitor("monitor", self)
        self.scoreboard = AHBScoreboard("scoreboard", self)

    def connect_phase(self):
        self.monitor.ap.connect(self.scoreboard.analysis_export)
