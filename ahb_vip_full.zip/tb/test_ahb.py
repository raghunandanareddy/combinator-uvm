import cocotb
from cocotb.clock import Clock
from cocotb.triggers import RisingEdge
from pyuvm import *
from ahb_env import Env
from ahb_seq import Seq

@pyuvm.test()
class Test(uvm_test):
    def build_phase(self):
        self.e=Env("e",self)

    async def run_phase(self):
        s=Seq("s")
        await s.start(self.e.d)

@cocotb.test()
async def run_test(dut):
    cocotb.start_soon(Clock(dut.HCLK,10,units="ns").start())
    dut.HRESETn.value=0
    for _ in range(5): await RisingEdge(dut.HCLK)
    dut.HRESETn.value=1
    await uvm_root().run_test("Test")
