from pyuvm import *
from cocotb.triggers import RisingEdge

class Driver(uvm_driver):
    async def run_phase(self):
        while True:
            t=await self.seq_item_port.get_next_item()
            for i in range(t.length):
                self.dut.HADDR.value=t.addr+i*4
                self.dut.HWRITE.value=t.write
                self.dut.HTRANS.value=2 if i==0 else 3
                await RisingEdge(self.dut.HCLK)
                while not int(self.dut.HREADY.value):
                    await RisingEdge(self.dut.HCLK)
                if t.write:
                    self.dut.HWDATA.value=t.data+i
            self.dut.HTRANS.value=0
            self.seq_item_port.item_done()
