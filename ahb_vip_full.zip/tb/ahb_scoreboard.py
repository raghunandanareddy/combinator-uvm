from pyuvm import *

class Scoreboard(uvm_component):
    def build_phase(self):
        self.exp=uvm_analysis_export("exp",self)
        self.fifo=uvm_tlm_analysis_fifo("fifo",self)
        self.mem={}

    def connect_phase(self):
        self.exp.connect(self.fifo.analysis_export)

    async def run_phase(self):
        while True:
            t=await self.fifo.get()
            if t["write"]:
                self.mem[t["addr"]]=t["data"]
            else:
                exp=self.mem.get(t["addr"],0)
                assert exp==t["rdata"], f"Mismatch {exp}!={t['rdata']}"
