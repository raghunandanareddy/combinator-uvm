from pyuvm import *
import random
from ahb_transaction import AHBTransaction

class Seq(uvm_sequence):
    async def body(self):
        for _ in range(10):
            t=AHBTransaction()
            t.addr=random.randint(0,64)*4
            t.write=random.choice([0,1])
            t.data=random.randint(0,255)
            t.length=random.choice([1,4])
            await self.start_item(t)
            await self.finish_item(t)
