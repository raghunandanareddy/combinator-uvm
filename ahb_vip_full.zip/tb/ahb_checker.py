from pyuvm import *
from cocotb.triggers import RisingEdge

class Checker(uvm_component):
    async def run_phase(self):
        while True:
            await RisingEdge(self.dut.HCLK)
            assert int(self.dut.HTRANS.value)!=1, "BUSY not supported"
            assert int(self.dut.HADDR.value)%4==0, "Unaligned address"
