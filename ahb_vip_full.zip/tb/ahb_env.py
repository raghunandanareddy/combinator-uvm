from pyuvm import *
from ahb_driver import Driver
from ahb_monitor import Monitor
from ahb_scoreboard import Scoreboard
from ahb_checker import Checker
from ahb_coverage import Coverage

class Env(uvm_env):
    def build_phase(self):
        self.d=Driver("d",self)
        self.m=Monitor("m",self)
        self.s=Scoreboard("s",self)
        self.c=Checker("c",self)
        self.cov=Coverage("cov",self)

    def connect_phase(self):
        self.m.ap.connect(self.s.exp)
        self.m.ap.connect(self.cov.exp)
