from pyuvm import *
class AHBTransaction(uvm_sequence_item):
    def __init__(self, name="txn"):
        super().__init__(name)
        self.addr=0; self.write=0; self.data=0
        self.length=1
