from pyuvm import *

class Coverage(uvm_component):
    def build_phase(self):
        self.exp=uvm_analysis_export("exp",self)
        self.fifo=uvm_tlm_analysis_fifo("fifo",self)
        self.r=0; self.w=0

    def connect_phase(self):
        self.exp.connect(self.fifo.analysis_export)

    async def run_phase(self):
        while True:
            t=await self.fifo.get()
            if t["write"]: self.w+=1
            else: self.r+=1
            self.logger.info(f"R={self.r} W={self.w}")
