module ahb_slave_mem (
    input HCLK,
    input HRESETn,
    input [31:0] HADDR,
    input HWRITE,
    input [1:0] HTRANS,
    input [31:0] HWDATA,
    output reg [31:0] HRDATA,
    output HREADY,
    output HREADYOUT
);
reg [31:0] mem [0:255];
assign HREADY = 1'b1;
assign HREADYOUT = 1'b1;
wire valid = HTRANS[1];
always @(posedge HCLK) begin
    if (!HRESETn) HRDATA <= 0;
    else if (valid) begin
        if (HWRITE) mem[HADDR[9:2]] <= HWDATA;
        else HRDATA <= mem[HADDR[9:2]];
    end
end
endmodule
