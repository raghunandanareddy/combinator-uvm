
module ahb_ram_adv(
    input HCLK, HRESETn,
    input HSEL,
    input [31:0] HADDR,
    input [1:0] HTRANS,
    input HWRITE,
    input [2:0] HSIZE,
    input [2:0] HBURST,
    input [31:0] HWDATA,
    input HREADY,

    output reg [31:0] HRDATA,
    output reg HREADYOUT,
    output reg [1:0] HRESP
);

reg [31:0] mem [0:255];
reg [1:0] wait_cnt;

wire valid = HSEL & HTRANS[1] & HREADY;

always @(posedge HCLK or negedge HRESETn) begin
    if (!HRESETn) begin
        HREADYOUT <= 1;
        HRESP <= 0;
        wait_cnt <= 0;
    end else begin
        if (wait_cnt != 0) begin
            wait_cnt <= wait_cnt - 1;
            HREADYOUT <= 0;
        end else begin
            HREADYOUT <= 1;
            HRESP <= 0;

            if (valid) begin
                wait_cnt <= 2;

                if (HWRITE)
                    mem[HADDR[9:2]] <= HWDATA;
                else
                    HRDATA <= mem[HADDR[9:2]];
            end
        end
    end
end

endmodule
