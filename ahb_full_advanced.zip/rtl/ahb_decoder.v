
module ahb_decoder(input [31:0] HADDR, output reg [1:0] HSEL);
always @(*) begin
    case(HADDR[12])
        1'b0: HSEL = 2'b01;
        1'b1: HSEL = 2'b10;
    endcase
end
endmodule
