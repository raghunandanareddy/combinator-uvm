
from cocotb.triggers import RisingEdge

class Monitor:
    def __init__(self, dut, cb):
        self.dut = dut
        self.cb = cb

    async def run(self):
        while True:
            await RisingEdge(self.dut.HCLK)
            txn = {
                "addr": int(self.dut.HADDR.value),
                "write": int(self.dut.HWRITE.value),
                "data": int(self.dut.HWDATA.value)
            }
            self.cb(txn)
