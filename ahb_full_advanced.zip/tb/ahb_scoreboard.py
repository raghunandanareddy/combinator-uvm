
class Scoreboard:
    def __init__(self):
        self.mem = {}

    def check(self, txn):
        if txn["write"]:
            self.mem[txn["addr"]] = txn["data"]
        else:
            if self.mem.get(txn["addr"],0) != txn["data"]:
                print("Mismatch", txn)
