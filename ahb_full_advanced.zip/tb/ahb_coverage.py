
from cocotb_coverage.coverage import CoverPoint, CoverCross

@CoverPoint("ahb.addr", xf=lambda t: t["addr"], bins=[0,64,128,192])
@CoverPoint("ahb.write", xf=lambda t: t["write"], bins=[0,1])
@CoverCross("ahb.cross", items=["ahb.addr","ahb.write"])
def sample(txn):
    pass
