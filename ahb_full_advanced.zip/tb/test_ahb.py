
import cocotb
from cocotb.clock import Clock
from cocotb.triggers import Timer
from ahb_master import AHBMaster
from ahb_monitor import Monitor
from ahb_scoreboard import Scoreboard
from ahb_coverage import sample

@cocotb.test()
async def run_test(dut):

    cocotb.start_soon(Clock(dut.HCLK, 10, units="ns").start())

    dut.HRESETn.value = 0
    await Timer(20, units="ns")
    dut.HRESETn.value = 1

    master = AHBMaster(dut)
    sb = Scoreboard()

    def cb(txn):
        sample(txn)
        sb.check(txn)

    cocotb.start_soon(Monitor(dut, cb).run())

    for i in range(100):
        await master.write(i, i*5)
        await master.read(i)

    from cocotb_coverage.coverage import coverage_db
    coverage_db.export_to_yaml("coverage.yaml")
