
from cocotb.triggers import RisingEdge

class AHBMaster:
    def __init__(self, dut):
        self.dut = dut

    async def write(self, addr, data):
        await RisingEdge(self.dut.HCLK)
        self.dut.HADDR.value = addr
        self.dut.HWRITE.value = 1
        self.dut.HTRANS.value = 2
        self.dut.HBURST.value = 1
        self.dut.HWDATA.value = data

    async def read(self, addr):
        await RisingEdge(self.dut.HCLK)
        self.dut.HADDR.value = addr
        self.dut.HWRITE.value = 0
        self.dut.HTRANS.value = 2
        await RisingEdge(self.dut.HCLK)
        return int(self.dut.HRDATA.value)
