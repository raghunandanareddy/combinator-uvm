import cocotb
from cocotb.triggers import RisingEdge
from cocotb_coverage.coverage import CoverPoint, CoverCross, coverage_db

@CoverPoint("ahb.htrans", xf=lambda tr: tr["HTRANS"], bins=[0,1,2,3])
@CoverPoint("ahb.hwrite", xf=lambda tr: tr["HWRITE"], bins=[0,1])
@CoverPoint("ahb.hsize", xf=lambda tr: tr["HSIZE"], bins=[0,1,2,3])
@CoverPoint("ahb.hburst", xf=lambda tr: tr["HBURST"], bins=list(range(8)))
@CoverPoint("ahb.haddr", xf=lambda tr: tr["HADDR"], bins=[0,1,2,3], rel=lambda v,b: (v & 0x3)==b)
@CoverPoint("ahb.hwdata", xf=lambda tr: tr["HWDATA"], bins=[0x0, 0xFFFFFFFF])
@CoverPoint("ahb.hrdata", xf=lambda tr: tr["HRDATA"], bins=[0x0, 0xFFFFFFFF])
@CoverPoint("ahb.hready", xf=lambda tr: tr["HREADY"], bins=[0,1])
@CoverPoint("ahb.hreadyout", xf=lambda tr: tr["HREADYOUT"], bins=[0,1])
@CoverPoint("ahb.hresp", xf=lambda tr: tr["HRESP"], bins=[0,1,2,3])

@CoverCross("ahb.cross_trans_write_size", items=["ahb.htrans","ahb.hwrite","ahb.hsize"])
@CoverCross("ahb.cross_burst_size", items=["ahb.hburst","ahb.hsize"])
@CoverCross("ahb.cross_resp_ready", items=["ahb.hresp","ahb.hready"])

def sample_ahb(tr):
    pass

prev_write = None
prev_addr = None
burst_count = 0

def track_sequences(tr):
    global prev_write, prev_addr, burst_count
    if prev_write == 1 and tr["HWRITE"] == 0:
        print("WRITE->READ transition covered")
    if prev_addr is not None:
        if tr["HADDR"] == prev_addr + (1 << tr["HSIZE"]):
            burst_count += 1
        else:
            burst_count = 0
    prev_write = tr["HWRITE"]
    prev_addr = tr["HADDR"]

def get_transaction(dut):
    return {
        "HTRANS": int(dut.HTRANS.value),
        "HWRITE": int(dut.HWRITE.value),
        "HSIZE": int(dut.HSIZE.value),
        "HBURST": int(dut.HBURST.value),
        "HADDR": int(dut.HADDR.value),
        "HWDATA": int(dut.HWDATA.value),
        "HRDATA": int(dut.HRDATA.value),
        "HREADY": int(dut.HREADY.value),
        "HREADYOUT": int(dut.HREADYOUT.value),
        "HRESP": int(dut.HRESP.value),
    }

async def ahb_monitor(dut):
    while True:
        await RisingEdge(dut.HCLK)
        if dut.HRESETn.value == 0:
            continue
        tr = get_transaction(dut)
        sample_ahb(tr)
        track_sequences(tr)

@cocotb.test()
async def test_ahb_coverage(dut):
    cocotb.start_soon(ahb_monitor(dut))
    for _ in range(500):
        await RisingEdge(dut.HCLK)
    coverage_db.report_coverage(cocotb.log.info, bins=True)
