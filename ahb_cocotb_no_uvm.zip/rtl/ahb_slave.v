
module ahb_slave(
    input clk,
    input hwrite,
    input [7:0] haddr,
    input [31:0] hwdata,
    output reg [31:0] hrdata
);

reg [31:0] mem [0:255];

always @(posedge clk) begin
    if (hwrite) begin
        mem[haddr] <= hwdata;
    end else begin
        hrdata <= mem[haddr];
    end
end

endmodule
