
import cocotb
from cocotb.triggers import Timer
from ahb_seq import AHBTransaction
from ahb_driver import AHBDriver
from ahb_monitor import AHBMonitor
from ahb_scoreboard import AHBScoreboard
from ahb_coverage import sample

@cocotb.test()
async def run_test(dut):

    driver = AHBDriver(dut)
    sb = AHBScoreboard()

    def cb(txn):
        sample(txn)
        sb.check(txn)

    monitor = AHBMonitor(dut, cb)
    cocotb.start_soon(monitor.run())

    for _ in range(100):
        txn = AHBTransaction()
        await driver.send(txn)
        await Timer(10, units="ns")
