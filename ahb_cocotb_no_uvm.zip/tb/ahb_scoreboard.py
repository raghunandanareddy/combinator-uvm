
class AHBScoreboard:
    def __init__(self):
        self.mem = {}

    def check(self, txn):
        if txn["write"]:
            self.mem[txn["addr"]] = txn["data"]
        else:
            exp = self.mem.get(txn["addr"], 0)
            if txn["data"] != exp:
                print(f"Mismatch at {txn['addr']}")
