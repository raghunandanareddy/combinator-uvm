
from cocotb.triggers import RisingEdge

class AHBMonitor:
    def __init__(self, dut, callback):
        self.dut = dut
        self.callback = callback

    async def run(self):
        while True:
            await RisingEdge(self.dut.clk)
            txn = {
                "addr": int(self.dut.haddr.value),
                "write": int(self.dut.hwrite.value),
                "data": int(self.dut.hwdata.value)
            }
            self.callback(txn)
