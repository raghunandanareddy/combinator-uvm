
import random

class AHBTransaction:
    def __init__(self):
        self.addr = random.randint(0, 255)
        self.write = random.choice([0,1])
        self.wdata = random.randint(0, 2**32 - 1)
