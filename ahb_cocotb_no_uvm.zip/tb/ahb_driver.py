
from cocotb.triggers import RisingEdge

class AHBDriver:
    def __init__(self, dut):
        self.dut = dut

    async def send(self, txn):
        await RisingEdge(self.dut.clk)
        self.dut.haddr.value = txn.addr
        self.dut.hwrite.value = txn.write
        self.dut.hwdata.value = txn.wdata
